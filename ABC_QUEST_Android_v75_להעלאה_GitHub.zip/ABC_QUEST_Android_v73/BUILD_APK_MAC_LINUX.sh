#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ -z "${ANDROID_HOME:-}" ]; then export ANDROID_HOME="${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}"; fi
if [ -z "${JAVA_HOME:-}" ]; then echo 'Note: JAVA_HOME should point to JDK 17.'; fi
if [ ! -f "$ANDROID_HOME/platforms/android-35/android.jar" ]; then echo 'Android SDK Platform 35 is missing. Install it from Android Studio SDK Manager.'; exit 1; fi
if [ ! -x .gradle-local/gradle-8.9/bin/gradle ]; then
  mkdir -p .gradle-local
  echo 'Downloading Gradle 8.9 (first build only)...'
  curl -fL --retry 2 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -o .gradle-local/gradle.zip
  unzip -q -o .gradle-local/gradle.zip -d .gradle-local
fi
.gradle-local/gradle-8.9/bin/gradle --no-daemon :app:assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk ABC_QUEST_v7_install.apk
echo 'Done: ABC_QUEST_v7_install.apk'
