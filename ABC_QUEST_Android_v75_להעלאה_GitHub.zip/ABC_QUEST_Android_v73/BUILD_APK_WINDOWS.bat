﻿@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
if "%ANDROID_HOME%"=="" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if "%ANDROID_SDK_ROOT%"=="" set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if "%JAVA_HOME%"=="" if exist "C:\Program Files\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
if "%JAVA_HOME%"=="" (
  echo ERROR: Install Android Studio or JDK 17 and set JAVA_HOME.
  pause
  exit /b 1
)
if not exist "%ANDROID_HOME%\platforms\android-35\android.jar" (
  echo ERROR: Android SDK 35 is missing. Open Android Studio SDK Manager and install Android SDK Platform 35.
  pause
  exit /b 1
)
if not exist ".gradle-local\gradle-8.9\bin\gradle.bat" (
  if not exist ".gradle-local" mkdir ".gradle-local"
  echo Downloading Gradle 8.9 once...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile '.gradle-local/gradle.zip'"
  if errorlevel 1 goto failed
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '.gradle-local/gradle.zip' -DestinationPath '.gradle-local' -Force"
  if errorlevel 1 goto failed
)
call ".gradle-local\gradle-8.9\bin\gradle.bat" --no-daemon :app:assembleDebug
if errorlevel 1 goto failed
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "ABC_QUEST_v7_להתקנה.apk"
echo.
echo Success! APK: ABC_QUEST_v7_להתקנה.apk
echo Transfer this APK to your Android phone and install it.
pause
exit /b 0
:failed
echo ERROR: Android APK build failed. Please review the messages above.
pause
exit /b 1
