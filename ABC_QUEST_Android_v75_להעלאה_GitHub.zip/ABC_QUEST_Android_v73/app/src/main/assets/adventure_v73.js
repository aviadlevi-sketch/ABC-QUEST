/* ABC QUEST v7.5: Four-world campaign, sixteen heroes, earned skins,
   mode-specific practice, daily pacing, and slower fame economy.
   Intended to run AFTER original application, offline-audio and v7.2 patches.
   No network, tracking, real money purchases, or remote content. */
(function(){
'use strict';
const QUEST_VERSION=6;
const WORLD_HEROES=[['alpha','beat','byte','shade'],['ziggy','luna','rex','flash'],['panda','nova','mix','ori'],['jet','kitty','orion','astra']];
const WORLD_COLORS=['#36c56c','#ed9651','#2cabef','#ad70ee'];
const WIN_REWARD_TROPHIES=220, WIN_REWARD_CREDITS=50;
const HERO_CREDIT_PRICES=[[0,80,160,260],[0,100,200,340],[0,120,250,420],[0,150,300,520]];
const HERO_TROPHY_GATES=[[0,400,1200,2400],[0,3000,4300,5700],[0,6900,8200,9800],[0,11500,13100,15500]];
const SKIN_CREDIT_PRICES=[[0,120,300,750],[0,180,450,1100],[0,250,650,1500],[0,350,900,2200]];
const FAME_TROPHIES=[0,300,900,1500,2200,3200,4500,6000,7600,9600,11500,13400,15500,17500,19500,22000,24500,27000,30500,34000,38000,43000,50000,60000];
const formatPrice=n=>Number(n||0).toLocaleString('en-US');
const heroCreditPrice=id=>HERO_CREDIT_PRICES[worldByHero(id)][slotByHero(id)];
const heroTrophyGate=id=>HERO_TROPHY_GATES[worldByHero(id)][slotByHero(id)];
const skinCreditPrice=(id,tier)=>SKIN_CREDIT_PRICES[worldByHero(id)][tier];
const skinTrophyGate=(id,tier)=>tier===0?0:heroTrophyGate(id)+[0,600,1500,3200][tier];
const EXTRA_REWARD_TROPHIES=110, EXTRA_REWARD_CREDITS=25;
const ALL_WORLD_REWARD_TROPHIES=110,ALL_WORLD_REWARD_CREDITS=25;
const ALL_WORLD_EXTRA_TROPHIES=55,ALL_WORLD_EXTRA_CREDITS=12;
const REWARD_TROPHIES_LETTER=90,REWARD_CREDITS_LETTER=20;
const DAILY_QUEST_WIN_LIMIT=4;
let gameWorldChoice='all';
let mapPreview=-1;
const debug=!!window.ABC_QUEST_DEBUG;
const trace=(...a)=>{if(debug)console.debug('[ABC QUEST 7.3]',...a)};

// The fourth-world secret hero is an original star explorer, with four
// truly different outfits: space pilot, noir detective, ancient mummy,
// and cosmic queen. The four images are not CSS recolors.
HEROES.push({id:'astra',name:'אסטרה',subtitle:'קוסמת הכוכבים',price:0,minTrophies:0,color:'#ae7bff',index:16});
HERO_SKIN_NAMES.astra=['אסטרה חלוצת החלל','אסטרה הבלשית','אסטרה המומיה','מלכת הכוכבים'];
HERO_IMAGES.astra=window.ABC_QUEST_ASTRA_SKINS || HERO_IMAGES.luna;
for(let tier=1;tier<=3;tier++)SKIN_LEVELS[tier].minTrophies=0;
SKIN_LEVELS[1].price=90;
SKIN_LEVELS[2].price=180;
SKIN_LEVELS[3].price=340;

const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const unique=x=>[...new Set(x)];
const safeInt=x=>Math.max(0,Number.isFinite(Number(x))?Math.floor(Number(x)):0);
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
function worldByHero(id){const idx=WORLD_HEROES.findIndex(ids=>ids.includes(id));return idx<0?0:idx;}
function slotByHero(id){return WORLD_HEROES[worldByHero(id)].indexOf(id);}
function worldRecords(i){return progress.worldRecords?.[i]?.wins || []}
function worldStats(i){
 const letters=stageLetters(i);
 const letterCount=letters.filter(l=>Boolean(progress.learned?.[l.up])).length;
 const records=worldRecords(i);
 return {letters:letterCount,total:letters.length,wins:records.length,
  days:unique(records.map(r=>r.date)).length,modes:unique(records.map(r=>r.mode)).length,
  dates:unique(records.map(r=>r.date)),modeNames:unique(records.map(r=>r.mode))};
}
function fameDays(){return unique([0,1,2,3].flatMap(i=>worldRecords(i).map(r=>r.date))).length}
function heroNeeds(i,slot){
 const n=stageLetters(i).length;
 if(slot===0)return {letters:0,wins:0,days:0,modes:0};
 if(slot===1)return {letters:2,wins:2,days:1,modes:1};
 if(slot===2)return {letters:Math.ceil(n*.65),wins:5,days:2,modes:2};
 return {letters:n,wins:10,days:3,modes:3};
}
function heroCheckpoint(i,slot){
 const s=worldStats(i), need=heroNeeds(i,slot);
 const unmet=[];
 if(s.letters<need.letters)unmet.push(`🔤 עוד ${need.letters-s.letters} אותיות`);
 if(s.wins<need.wins)unmet.push(`🎮 עוד ${need.wins-s.wins} משחקים מוצלחים`);
 if(s.days<need.days)unmet.push(`📅 עוד ${need.days-s.days} ימי תרגול`);
 if(s.modes<need.modes)unmet.push(`🎯 עוד ${need.modes-s.modes} סוגי משחק`);
 if(slot>0&&!progress.questClaimedHeroes?.[WORLD_HEROES[i][slot-1]])unmet.push('🎭 קודם פותחים את הדמות הקודמת במסלול');
 const id=WORLD_HEROES[i][slot],gate=heroTrophyGate(id);
 if(progress.stars<gate)unmet.push(`🏆 עוד ${formatPrice(gate-progress.stars)} גביעים`);
 return {ready:unmet.length===0,need,s,unmet};
}
function worldOpen(i){
 if(i===0)return true;
 if(i<0||i>3)return false;
 const prevLast=WORLD_HEROES[i-1][3];
 return !!progress.questClaimedHeroes?.[prevLast]; // keep previously earned worlds unlocked
}
function heroUnlockedByJourney(id){
 const i=worldByHero(id),slot=slotByHero(id);
 return worldOpen(i)&&heroCheckpoint(i,slot).ready;
}
function maybeAutoOpenWorldHero(){
 let changed=false;
 for(let i=0;i<4;i++){
  if(!worldOpen(i))break;
  const id=WORLD_HEROES[i][0];
  if(!progress.questClaimedHeroes[id]){progress.questClaimedHeroes[id]=true;changed=true;}
  if(!ownsHero(id)){
   progress.ownedHeroes.push(id);
   progress.ownedSkins[id]=[0];
   progress.equippedSkins[id]=0;
   changed=true;
  }
 }
 if(changed)save();
}
function initQuest(){
 if(!progress.worldRecords||typeof progress.worldRecords!=='object')progress.worldRecords={};
 for(let i=0;i<4;i++){
  const record=progress.worldRecords[i];
  if(!record||typeof record!=='object')progress.worldRecords[i]={wins:[]};
  if(!Array.isArray(progress.worldRecords[i].wins))progress.worldRecords[i].wins=[];
 }
 if(!progress.questClaimedHeroes||typeof progress.questClaimedHeroes!=='object')progress.questClaimedHeroes={};
 if(!progress.questDailyRewards||typeof progress.questDailyRewards!=='object')progress.questDailyRewards={};
 if(!Number.isFinite(progress.questXP))progress.questXP=0;
 if(!Number.isFinite(progress.questVersion)){
  // Keep earned trophies, credits, characters and previously reached fame.
  // The new slower fame track uses unique accomplishments rather than grindable hits.
  progress.legacyGloryFloor=Math.max(0,GLORY.findLastIndex(g=>progress.stars>=g.min));
  progress.questVersion=QUEST_VERSION;
 }
 if(!Number.isFinite(progress.legacyGloryFloor))progress.legacyGloryFloor=0;
 if(progress.economyVersion!==75){
  progress.stars=safeInt(progress.stars)*30;
  progress.credits=safeInt(progress.credits)*4;
  progress.economyVersion=75;
  progress.questVersion=QUEST_VERSION;
 }

 maybeAutoOpenWorldHero();
 save();
}
initQuest();

function skinRequirements(id,tier){
 const i=worldByHero(id),slot=slotByHero(id),s=worldStats(i),base=heroNeeds(i,slot);
 const need={wins:base.wins+[0,2,4,6][tier],days:[0,2,3,4][tier],modes:[0,1,3,4][tier],trophies:skinTrophyGate(id,tier)};
 const problems=[];
 if(!worldOpen(i))problems.push('העולם עדיין נעול');
 if(!ownsHero(id))problems.push('פותחים קודם את הדמות');
 if(s.wins<need.wins)problems.push(`עוד ${need.wins-s.wins} ניצחונות בעולם`);
 if(s.days<need.days)problems.push(`עוד ${need.days-s.days} ימי תרגול`);
 if(s.modes<need.modes)problems.push(`עוד ${need.modes-s.modes} סוגי משחק`);
 if(progress.stars<need.trophies)problems.push(`עוד ${formatPrice(need.trophies-progress.stars)} גביעים`);
 return {ready:!problems.length,problems,need,s};
}
function worldHeroHtml(i,compact=false){
 return WORLD_HEROES[i].map((id,slot)=>{
  const h=getHero(id),own=ownsHero(id),checkpoint=heroCheckpoint(i,slot),claimed=!!progress.questClaimedHeroes[id],open=worldOpen(i);
  const ready=open&&checkpoint.ready;
  return `<button class="quest-hero-icon ${claimed?'claimed':ready?'ready':'locked'}" data-action="quest-open-hero" data-hero="${id}" aria-label="${h.name}: ${ready?'זמין לפתיחה':'נעול'}" title="${h.name}">
   ${artHtml(id,0,'quest-hero-pic')}<span class="quest-hero-lock">${claimed?'✓':ready?'🎁':'🔒'}</span>
   ${compact?'':`<span class="quest-hero-name">${h.name}</span>`}</button>`;
 }).join('');
}
function heroJourneyRow(h){
 const i=worldByHero(h.id),slot=slotByHero(h.id),cp=heroCheckpoint(i,slot);
 const claimed=!!progress.questClaimedHeroes[h.id];
 const price=heroCreditPrice(h.id),gate=heroTrophyGate(h.id),creditGap=Math.max(0,price-progress.credits);
 const labels=[`🌍 עולם ${i+1}: ${STAGES[i].name}`,`🔤 ${cp.s.letters}/${cp.need.letters} אותיות`,`🎮 ${cp.s.wins}/${cp.need.wins} ניצחונות`,`📅 ${cp.s.days}/${cp.need.days} ימים`,`🎯 ${cp.s.modes}/${cp.need.modes} סוגים`];
 return `<div class="quest-hero-progress"><div class="quest-hero-payments"><span>🏆 ${formatPrice(gate)} גביעים</span><span>🪙 ${formatPrice(price)} קרדיטים</span>${creditGap&&!claimed?`<span class="need">חסרים ${formatPrice(creditGap)} קרדיטים</span>`:''}</div><div class="quest-mini-tags">${labels.map(t=>`<span>${t}</span>`).join('')}</div>
 <div class="quest-hero-explainer">${claimed?'⭐ פרס המסע כבר נפתח':!worldOpen(i)?'🔒 יש לסיים את העולם הקודם':cp.ready?'🎁 השלמת אתגר הדמות! אפשר לפתוח אותה עכשיו.':cp.unmet.join(' · ')}</div></div>`;
}

/* Honest user-visible collection: four groups, four heroes each. */
heroActionHtml=function(h){
 const claimed=!!progress.questClaimedHeroes[h.id],cp=heroCheckpoint(worldByHero(h.id),slotByHero(h.id));
 if(!claimed&&worldOpen(worldByHero(h.id))&&cp.ready)
  return `<button class="btn gold-button" data-action="quest-claim-hero" data-hero="${h.id}">${heroCreditPrice(h.id)?`🪙 ${formatPrice(heroCreditPrice(h.id))} · רכישת ${h.name}`:`🎁 פתיחת ${h.name} בחינם`}</button>`;
 if(ownsHero(h.id))return `<button class="btn teal" data-action="equip-hero" data-hero="${h.id}" ${progress.equippedHero===h.id?'disabled':''}>${progress.equippedHero===h.id?'✓ הדמות שלי':'⭐ בחירת דמות'}</button>`;
 return `<button class="btn outline" disabled>🔒 משלימים אתגר בעולם ${worldByHero(h.id)+1}</button>`;
};
heroCard=function(h,context='heroes'){
 const own=ownsHero(h.id),claimed=!!progress.questClaimedHeroes[h.id],cp=heroCheckpoint(worldByHero(h.id),slotByHero(h.id));
 const selected=(context==='heroes'?browsedHeroId:shopHeroId)===h.id;
 const reward=worldOpen(worldByHero(h.id))&&cp.ready&&!claimed;
 return `<button class="collectible-card ${selected?'selected':''} ${own?'owned':'locked'} ${reward?'quest-ready':''}" data-action="${context==='heroes'?'browse-hero':'shop-target-hero'}" data-hero="${h.id}">
 <span class="portrait-wrap">${artHtml(h.id,0)}<span class="collectible-mark">${reward?'🎁':own?'✓':'🔒'}</span></span>
 <span class="collectible-title">${h.name}</span><span class="quest-card-economy"><span>🏆 ${formatPrice(heroTrophyGate(h.id))}</span><span>🪙 ${formatPrice(heroCreditPrice(h.id))}</span></span><span class="collectible-price">${reward?'⭐ תנאי פתיחה הושלמו':claimed?'✓ הושגה':own?'✓ נפתחה בעבר':'🔒 משימות עולם'}</span></button>`;
};
heroesPage=function(){
 const h=getHero(browsedHeroId),owned=ownsHero(h.id),tier=owned?equippedTier(h.id):0;
 return `<div class="collectible-header"><div><span class="game-kicker">🎭 MY LOCKER</span><h1>16 הגיבורים שלי</h1><p>ארבע דמויות בכל עולם — משיגים אותן באמצעות משימות!</p></div><button class="btn gold-button" data-action="navigate" data-page="shop">✨ לחנות הסקינים</button></div>
 <section class="hero-showcase"><div class="hero-display">${artHtml(h.id,tier,'showcase-portrait')}<span class="portrait-badge">${owned?'✓ נפתחה':'🔒 נעולה'}</span></div>
 <div class="hero-profile"><span class="game-kicker">דמות ${h.index} מתוך 16 · עולם ${worldByHero(h.id)+1}</span><h2>${h.name}</h2><p>${h.subtitle}</p>${heroJourneyRow(h)}
 <div class="hero-action-row">${heroActionHtml(h)}<button class="btn outline" data-action="open-hero-skins" data-hero="${h.id}">✨ ארבעת הסקינים</button></div></div></section>
 ${STAGES.map((s,i)=>`<section class="quest-hero-group"><div class="quest-group-top" style="--world-color:${WORLD_COLORS[i]}"><h2>${s.emoji} ${s.name}</h2><span>${stageLetters(i)[0].up}–${stageLetters(i).at(-1).up}</span><button class="btn small outline" data-action="quest-open-world" data-stage="${i}">${worldOpen(i)?'למסלול בעולם ←':'🔒 צפייה בתנאים'}</button></div>
 <div class="collectible-grid">${WORLD_HEROES[i].map(id=>heroCard(getHero(id),'heroes')).join('')}</div></section>`).join('')}
 <p class="quest-note">💡 לכל דמות וסקין נדרשים משימות, גביעים וקרדיטים. אין רכישות בכסף אמיתי.</p>`;
};

/* Skin art stays different; gate purchases by earned milestones. */
skinCard=function(h,tier){
 const own=ownsSkin(h.id,tier.id),equipped=ownsHero(h.id)&&equippedTier(h.id)===tier.id,req=skinRequirements(h.id,tier.id);
 const price=skinCreditPrice(h.id,tier.id),purchasable=!own&&req.ready&&progress.credits>=price;
 const label=equipped?'מצויד ✓':own?'לבוש את הסקין':!req.ready?'🔒 עוד לא נפתח':progress.credits<price?`חסרים ${formatPrice(price-progress.credits)} 🪙`:`🪙 ${formatPrice(price)} · קנייה`;
 return `<article class="skin-card skin-${tier.rarity}"><div class="skin-card-art">${artHtml(h.id,tier.id)}<span class="skin-card-badge">${rarityLabel(tier.id)}</span></div>
 <div class="skin-card-info"><h3>${HERO_SKIN_NAMES[h.id][tier.id]}</h3><div class="skin-economy"><span>🏆 ${formatPrice(req.need.trophies)}</span><span>🪙 ${formatPrice(price)}</span></div><p>${tier.id===0?'מראה הבסיס של הדמות':`🌍 ${STAGES[worldByHero(h.id)].name} · ${req.s.wins}/${req.need.wins} משחקים · ${req.s.days}/${req.need.days} ימים`}</p>
 ${!own&&!req.ready?`<p class="skin-quest-status">${req.problems.join(' · ')}</p>`:''}
 <button class="btn ${own?'teal':purchasable?'gold-button':'outline'}" data-action="${own?'equip-skin':'buy-skin'}" data-hero="${h.id}" data-tier="${tier.id}" ${equipped||(!own&&!purchasable)?'disabled':''}>${label}</button></div></article>`;
};
shopPage=function(){
 const h=getHero(shopHeroId),isHeroTab=shopTab==='heroes';
 return `<div class="collectible-header"><div><span class="game-kicker">🛒 THE SKIN SHOP</span><h1>חנות הדמויות והסקינים</h1><p>פותחים דמויות וסקינים לאחר משימות, גביעים ורכישה בקרדיטים.</p></div><div class="shop-balance">🪙 <b>${progress.credits}</b></div></div>
 <div class="shop-tabs"><button class="${isHeroTab?'active':''}" data-action="shop-tab" data-tab="heroes">🎭 דמויות לפי עולם</button><button class="${!isHeroTab?'active':''}" data-action="shop-tab" data-tab="skins">✨ סקינים</button></div>
 ${isHeroTab?`<div class="shop-worlds">${STAGES.map((s,i)=>`<section class="quest-hero-group"><div class="quest-group-top" style="--world-color:${WORLD_COLORS[i]}"><h2>${s.emoji} ${s.name}</h2><span>ארבע דמויות</span></div><div class="collectible-grid">${WORLD_HEROES[i].map(id=>heroCard(getHero(id),'shop')).join('')}</div></section>`).join('')}</div>
 <div class="shop-selection"><div class="shop-selection-art">${artHtml(h.id,0)}</div><div><h2>${h.name}</h2>${heroJourneyRow(h)}<div class="hero-action-row">${heroActionHtml(h)}<button class="btn outline" data-action="open-hero-skins" data-hero="${h.id}">✨ כל הסקינים</button></div></div></div>`:
 `<div class="skin-feature"><div class="skin-feature-top"><div><h2>סקינים של ${h.name}</h2><p>ארבע הופעות נועזות. לכל סקין דרישות משלו.</p></div><button class="btn outline" data-action="choose-shop-hero">↔ החלפת דמות</button></div><div class="shop-hero-picker">${HEROES.map(x=>`<button class="picker-avatar ${h.id===x.id?'active':''}" data-action="shop-target-hero" data-hero="${x.id}" aria-label="סקינים של ${x.name}">${artHtml(x.id,0)}</button>`).join('')}</div></div>
 <div class="skin-grid">${SKIN_LEVELS.map(t=>skinCard(h,t)).join('')}</div>`}
 <div class="shop-note">🎁 דמויות פותחים בעולם שלהן, וסקינים בכסף משחק בלבד. לעולם אין רכישה בכסף אמיתי.</div>`;
};

/* Interactive journey map is the entry point, each world leads to its own detail screen. */
mapPage=function(){
 return `<div class="screen-back"><button class="btn ghost" data-action="navigate" data-page="home">→ 🏠 לבית</button></div>
 <div class="quest-map-head"><span class="game-kicker">🧭 ADVENTURE MAP</span><h1>🗺️ מפת ההרפתקה</h1><p>בכל עולם אותיות חדשות, ארבע דמויות וסקינים שאפשר להשיג. סיימו משימות כדי להגיע לעולם הבא!</p></div>
 <div class="quest-world-map"><svg class="quest-route" viewBox="0 0 800 690" preserveAspectRatio="none" aria-hidden="true"><path d="M600 110 C430 60 300 175 255 265 S570 345 590 450 S425 520 240 590" fill="none" stroke="#fff5aa" stroke-width="14" stroke-linecap="round" stroke-dasharray="17 21" opacity=".65"/></svg>
 ${STAGES.map((s,i)=>{
 const st=worldStats(i),open=worldOpen(i),heroCount=WORLD_HEROES[i].filter(id=>progress.questClaimedHeroes[id]).length;
 const pct=Math.round((st.letters/st.total*.45+clamp(st.wins/10,0,1)*.35+clamp(st.days/3,0,1)*.2)*100);
 return `<button class="quest-world-node quest-world-${i} ${open?'available':'closed'}" style="--world-color:${WORLD_COLORS[i]}" data-action="quest-open-world" data-stage="${i}" aria-label="${s.name}; ${open?'פתוח':'נעול'}; ${st.letters} מתוך ${st.total} אותיות">
 <span class="quest-world-emoji">${s.emoji}</span><strong>${s.name}</strong><span class="quest-range" dir="ltr">${stageLetters(i)[0].up} – ${stageLetters(i).at(-1).up}</span>
 <span class="quest-world-avatars">${WORLD_HEROES[i].map(id=>`<img src="${skinImage(id,0)}" alt="" class="${progress.questClaimedHeroes[id]?'':'quest-silhouette'}" loading="lazy">`).join('')}</span>
 <span class="quest-world-track"><span style="width:${pct}%"></span></span>
 <span class="quest-world-caption">${st.letters}/${st.total} אותיות · ${st.wins}/10 ניצחונות · ${heroCount}/4 גיבורים</span><span class="quest-world-status">${open?'לחצו כדי להיכנס ←':'🔒 הסתכלו בתנאי הפתיחה'}</span></button>`;
 }).join('')}</div>
 <div class="quest-map-explain"><b>🎯 איך מתקדמים?</b><span>לומדים אותיות ← מצליחים במשחקים בעולם ← חוזרים ביום נוסף ← פותחים ארבע דמויות ← מגיעים לעולם הבא.</span></div>`;
};
function checkpointCard(i,id,slot){
 const cp=heroCheckpoint(i,slot),h=getHero(id),claimed=!!progress.questClaimedHeroes[id],ready=worldOpen(i)&&cp.ready;
 return `<div class="quest-checkpoint ${claimed?'claimed':ready?'ready':'locked'}"><div class="quest-checkpoint-art">${artHtml(id,0,'quest-hero-pic')}<span>${claimed?'✅':ready?'🎁':'🔒'}</span></div> <div class="quest-checkpoint-body"><b>${h.name}</b><div class="quest-checkpoint-economy"><span>🏆 ${formatPrice(heroTrophyGate(id))}</span><span>🪙 ${formatPrice(heroCreditPrice(id))}</span></div><small>${slot===0?'פתיחה בכניסה לעולם':`${cp.need.letters} אותיות · ${cp.need.wins} משחקים · ${cp.need.days} ימים · ${cp.need.modes} סוגים`}</small><span class="quest-checkpoint-status">${claimed?'הושג':ready?'מוכן לקבלה!':cp.unmet.join(' · ')}</span></div>${ready&&!claimed?`<button class="btn gold-button" data-action="quest-claim-hero" data-hero="${id}">${heroCreditPrice(id)?`🪙 ${formatPrice(heroCreditPrice(id))} · רכישה`:`🎁 קבלה`}</button>`:''}</div>`;
}
stagePage=function(){
 const i=selectedStage,s=STAGES[i],st=worldStats(i),open=worldOpen(i),letters=stageLetters(i),prev=i>0?STAGES[i-1]:null;
 const header=`<button class="text-link" data-action="navigate" data-page="map">→ חזרה למפת המסע</button><div class="quest-stage-head" style="--world-color:${WORLD_COLORS[i]}"><div class="quest-stage-scene">${s.emoji}</div><div><small>פרק ${i+1} מתוך 4</small><h1>${s.name}</h1><p>${s.desc} · אותיות ${letters[0].up}–${letters.at(-1).up}</p></div></div>`;
 if(!open)return header+`<section class="quest-locked-stage"><div class="quest-lock-symbol">🔒</div><h2>העולם עדיין נעול</h2><p>כדי להגיע ל${s.name}, מסיימים את משימות הדמות הרביעית ב${prev.name} ותובעים את הפרס שלה.</p><button class="btn gold-button" data-action="quest-open-world" data-stage="${i-1}">🗺️ לחזור ל${prev.name}</button></section>
 <div class="quest-section-header"><h2>🎭 ארבע הדמויות שאפשר להשיג</h2></div><div class="quest-checkpoint-list">${WORLD_HEROES[i].map((id,slot)=>checkpointCard(i,id,slot)).join('')}</div>`;
 return header+`<section class="quest-world-dashboard"><div><b>🔤 ${st.letters}/${st.total}</b><small>אותיות שלמדנו</small></div><div><b>🎮 ${st.wins}/7</b><small>משחקים מוצלחים</small></div><div><b>📅 ${st.days}/2</b><small>ימי תרגול שונים</small></div><div><b>🎯 ${st.modes}/3</b><small>סוגי משחק</small></div></section>
 <div class="quest-rule-hint">ניצחון במשימת עולם = לפחות 6 מתוך 8 תשובות נכונות. ארבעת הניצחונות הראשונים בכל עולם וביום מקדמים גם את משימות הדמויות ומעניקים פרס מלא. מהמשחק החמישי מקבלים חצי מכמות הגביעים והקרדיטים, כך שכדאי להמשיך להתאמן.</div>
 <div class="quest-section-header"><h2>🎭 תחנות הדמויות</h2><span>${WORLD_HEROES[i].filter(id=>progress.questClaimedHeroes[id]).length} מתוך 4</span></div><div class="quest-checkpoint-list">${WORLD_HEROES[i].map((id,slot)=>checkpointCard(i,id,slot)).join('')}</div>
 <div class="quest-section-header"><h2>🔤 אותיות העולם</h2><span>${st.letters}/${st.total}</span></div><div class="letter-grid">${letters.map(letterTile).join('')}</div>
 <div class="quest-stage-cta"><button class="btn gold-button" data-action="start-lesson">📘 ממשיכים ללמוד אותיות</button><button class="btn teal" data-action="quest-practice-world" data-stage="${i}">🎮 מתרגלים בעולם הזה</button></div>`;
};

/* Game room: explicit world choice including all worlds. */
gamesPage=function(){
 return `<div class="quest-map-head"><span class="game-kicker">🎮 GAME ROOM</span><h1>חדר המשחקים</h1><p>בחרו עולם לתרגול — או ערבבו את כל העולמות. ניצחונות בעולם מסוים מקדמים את ארבע הדמויות שלו.</p></div>
 <section class="quest-game-selector"><h2>🌍 איפה משחקים?</h2><div class="quest-game-worlds"><button class="quest-scope ${gameWorldChoice==='all'?'active':''}" data-action="quest-select-game-world" data-world="all"><span>🌐</span><b>כל העולמות</b><small>A–Z · לתרגול חופשי</small></button>
 ${STAGES.map((s,i)=>`<button class="quest-scope ${String(gameWorldChoice)===String(i)?'active':''} ${worldOpen(i)?'':'disabled'}" data-action="quest-select-game-world" data-world="${i}" ${worldOpen(i)?'':'disabled'}><span>${s.emoji}</span><b>${s.name}</b><small>${stageLetters(i)[0].up}–${stageLetters(i).at(-1).up} · ${worldOpen(i)?`${worldStats(i).wins} ניצחונות`:'🔒 נעול'}</small></button>`).join('')}</div></section>
 <div class="quest-scope-hint">${gameWorldChoice==='all'?'🌐 התרגול יכלול אותיות מכל ארבעת העולמות.':`🎯 ניצחון ב${STAGES[Number(gameWorldChoice)].name} מקדם את הדמויות של העולם הזה.`}</div>
 <div class="game-modes">${GAME_MODES.map(m=>`<button class="game-mode" style="--shade:${m.shade}" data-action="start-game" data-mode="${m.id}"><span class="game-icon">${m.emoji}</span><h3>${m.name}</h3><p>${m.desc}</p><span class="tag">8 שאלות · פרס על תרגול מוצלח</span></button>`).join('')}</div>`;
};
const baseBeginGame=beginGame;
beginGame=function(mode='mixed',scope=null,diagnostic=false){
 const target=diagnostic?'all':scope==null?gameWorldChoice:scope;
 if(typeof target==='number'&&!worldOpen(target)){
  page='map';render();showToast('🔒 העולם הזה ייפתח אחרי המשימות בעולם הקודם.');return;
 }
 baseBeginGame(mode,target,diagnostic);
};

/* Balanced economy: no per-tap trophies; earn on qualified completed rounds.
   Up to 4 successful rounds per world/day count towards hero quests,
   but later victories still earn half the trophies and credits.
   Old trophies are retained and never spent or erased. */
const baseMarkLearned=markLearned;
markLearned=function(up){
 const l=locate(String(up||'').toUpperCase());if(!l)return;
 const ownedAlready=!!(progress.learned[l.up]||progress.claimedLetterRewards?.[l.up]);
 if(!worldOpen(l.stage)&&!ownedAlready){showToast('🔒 האות שייכת לעולם נעול. פותחים אותו קודם במפה.');return;}
 const stars=progress.stars,credits=progress.credits;
 baseMarkLearned(l.up);
 if(!ownedAlready){
  progress.stars=stars+REWARD_TROPHIES_LETTER;
  progress.credits=credits+REWARD_CREDITS_LETTER;
  progress.questXP+=2;
 }
 save();
};
// One render per answer keeps the 3MB offline art bundle responsive on phones.
answerQuestion=function(up){
 if(!game||game.question.answered)return;
 const q=game.question;
 q.choice=up;
 q.answered=true;
 const right=up===q.target;
 if(right)game.correct++;
 if(game.diagnostic)game.diagnosticResults.push({up:q.target,kind:q.type,right});
 else{
  const old=stat(q.target,q.type);
  progress.results[q.target]??={};
  progress.results[q.target][q.type]={correct:old.correct+(right?1:0),total:old.total+1,lastAt:Date.now()};
 }
 save();render();
};
recordReadingSelfCheck=function(success){
 if(!game||game.question.answered||game.question.type!=='read')return;
 stopReadingMic();
 const q=game.question;q.answered=true;q.choice=success?'self-yes':'self-try';
 if(success)game.correct++;
 if(!game.diagnostic){
  for(const up of q.sequence){
   const old=stat(up,'reading');
   progress.results[up]??={};
   progress.results[up].reading={total:old.total+1,correct:old.correct+(success?1:0),lastAt:Date.now()};
  }
 }
 save();render();
};
const baseNextQuestion=nextQuestion;
nextQuestion=function(){
 if(!game)return;
 if(game.at+1<game.length){baseNextQuestion();return;}
 stopReadingMic();readingStatus='';readingTranscript='';readingMatched=false;
 const date=today(),scope=game.scope,mode=game.mode,correct=game.correct,length=game.length,diagnostic=game.diagnostic;
 progress.sessions++;progress.completed++;progress.lastSession=Date.now();
 let starsEarned=0,creditsEarned=0,qualified=false,recorded=false;
 if(diagnostic){
  progress.diagnostic={date:Date.now(),total:length,correct,results:game.diagnosticResults};
 }else{
  qualified=correct>=Math.ceil(length*.75) && mode!=='read';
  const world=typeof scope==='number'?scope:'all';
  if(qualified&&world!=='all'&&worldOpen(world)){
   const records=worldRecords(world),daily=records.filter(r=>r.date===date).length;
   if(daily<DAILY_QUEST_WIN_LIMIT){
    records.push({date,mode,score:correct,total:length});
    progress.worldRecords[world].wins=records;
    starsEarned=WIN_REWARD_TROPHIES;
    creditsEarned=WIN_REWARD_CREDITS;
    progress.questXP+=5;
    recorded=true;
   }else{
    // Reduced reward, not zero: daily quest counters stay capped,
    // but completed practice is always worth celebrating.
    starsEarned=EXTRA_REWARD_TROPHIES;
    creditsEarned=EXTRA_REWARD_CREDITS;
   }
  }else if(qualified&&world==='all'){
   // All-world mode is free practice and awards fewer trophies than a
   // specific world's quest. No loss of points after the second win.
   const key='all:'+date,n=safeInt(progress.questDailyRewards[key]);
   progress.questDailyRewards[key]=n+1;
   starsEarned=n<2?ALL_WORLD_REWARD_TROPHIES:ALL_WORLD_EXTRA_TROPHIES;
   creditsEarned=n<2?ALL_WORLD_REWARD_CREDITS:ALL_WORLD_EXTRA_CREDITS;
  }
  progress.stars+=starsEarned;
  progress.credits+=creditsEarned;
 }
 progress.lastQuestReward={stars:starsEarned,credits:creditsEarned,qualified,recorded,scope,mode,date};
 page='finish';save();render();
};
finishPage=function(){
 if(!game)return '<div class="empty">בחרו משחק!</div>';
 const pct=Math.round(game.correct*100/game.length),r=progress.lastQuestReward||{stars:0,credits:0};
 const won=!game.diagnostic&&pct>=75&&game.mode!=='read',world=typeof game.scope==='number'?game.scope:'all';
 const counted=won&&r.recorded&&r.scope===game.scope;
 const targetPage=world==='all'?'games':'stage';
 return `<div class="finish"><div class="confetti">✨ 🏆 🎊</div><div class="emoji">${pct>=75?'🏆':'💛'}</div><h2>${pct>=75?'הצלחת במשימה!':'עוד תרגול ונתקדם!'}</h2>
 <div class="score">${game.correct} / ${game.length}</div><p>${pct}% תשובות נכונות</p>
 ${game.diagnostic?'<div class="hintbox">זו בדיקת פתיחה ללא ניקוד. ממשיכים ללמוד!</div>':`<div class="finish-rewards"><span>🏆 +${formatPrice(r.stars||0)}</span><span>🪙 +${formatPrice(r.credits||0)}</span></div>
 <div class="quest-finish-message">${counted?`🌟 עוד ניצחון נרשם ב${STAGES[world].name}!`:
 game.mode==='read'?'🎙️ יופי של קריאה! זהו תרגול עצמי, ולכן אינו מעניק ניצחון רשמי במסע.':won&&world!=='all'?'🎯 הצלחת! ניצחונות נוספים היום מעניקים חצי מהגביעים והקרדיטים. מחר ייפתחו שוב ארבע משימות מלאות.':
 won?'🌐 יופי! תרגול כל העולמות אינו מחליף משימות של עולם מסוים.':'🎮 צריך לפחות 6 תשובות נכונות מתוך 8 כדי להתקדם במסע.'}</div>`}
 <div class="summary-actions"><button class="btn" data-action="restart-game">משחק נוסף 🔁</button>
 <button class="btn outline" data-action="${world==='all'?'navigate':'quest-open-world'}" data-page="games" data-stage="${world==='all'?0:world}">${world==='all'?'🎮 חדר המשחקים':'🗺️ חזרה לעולם'}</button></div></div>`;
};

/* Fame is once again based entirely on earned trophies, NOT quest XP.
   The 24 levels are tuned for about ten practice days at ~10 successful
   rounds/day, plus one-time letters; grinding faster remains possible. */
const TROPHY_FAME_THRESHOLDS=FAME_TROPHIES;
for(let i=0;i<GLORY.length;i++)GLORY[i].min=TROPHY_FAME_THRESHOLDS[i];
currentGlory=function(){return [...GLORY].reverse().find(g=>safeInt(progress.stars)>=g.min)||GLORY[0];};
fameTrackHtml=function(){
 const current=currentGlory(),next=GLORY.find(g=>g.min>safeInt(progress.stars));
 const until=next?next.min-safeInt(progress.stars):0;
 const tiles=Array.from({length:8},(_,i)=>{
  const levels=GLORY.slice(i*3,i*3+3);
  return `<div class="fame-tile ${progress.stars>=levels[0].min?'fame-open':'fame-locked'}"><div class="fame-icon">${levels[0].icon}</div><strong>${levels[0].name.replace(/\s[IV]+$/,'')}</strong><small>${levels.map(g=>progress.stars>=g.min?'●':'○').join(' ')}</small><span>${formatPrice(levels[0].min)} 🏆</span></div>`;
 }).join('');
 return `<section class="fame-road"><div class="fame-head"><div><span class="game-kicker">👑 מסלול התהילה</span><h2>${current.icon} ${current.name}</h2></div><span>${next?`${formatPrice(until)} 🏆 לדרגה הבאה`:'🏆 השגת את תהילת השיא!'}</span></div>
 <div class="quest-prestige-info"><span>🏆 ${formatPrice(progress.stars)} גביעים</span><span>🎯 ${next?`הדרגה הבאה ב־${formatPrice(next.min)} גביעים`:'כל הדרגות נפתחו'}</span><span>📅 ${fameDays()} ימי תרגול</span></div>
 <div class="fame-tiles">${tiles}</div><p>תהילה נקבעת לפי גביעים, בדיוק כמו במודל המקורי. מקבלים 220 גביעים בניצחונות 1–4 בכל עולם ביום, 110 בניצחונות נוספים, ו־90 גביעים ללימוד אות חדשה פעם אחת. תהילת השיא ב־60,000 גביעים.</p></section>`;
};

const baseHomePage=homePage;
homePage=function(){
 let html=baseHomePage();
 html=html.replace(/data-action="open-stage" data-stage="\d+"/, 'data-action="navigate" data-page="map"');
 html=html.replace(/\/15/g,'/16');
 return html.replace('</section></div>',`</section><section class="quest-home-ribbon"><span>🗺️ ארבעה עולמות</span><b>🎭 16 גיבורים</b><span>📅 מסע של כ־10 ימים</span><button class="btn gold-button" data-action="navigate" data-page="map">למפת ההרפתקה ←</button></section></div>`);
};

const baseProgressPage=progressPage;
progressPage=function(){
 return `<div class="quest-progress-intro"><h1>🏆 ההתקדמות שלי במסע</h1><p>ניצחונות אמיתיים והתקדמות בעולם פותחים פרסים ודרגות תהילה. נתוני הגביעים והסקינים הישנים נשמרו.</p>
 <div class="quest-progress-summary"><b>🏆 ${formatPrice(progress.stars)} גביעים</b><b>🪙 ${formatPrice(progress.credits)} קרדיטים</b><b>🎭 ${progress.ownedHeroes.length}/16 דמויות</b><b>📅 ${fameDays()} ימי תרגול</b></div></div>
 ${fameTrackHtml()}
 <div class="quest-progress-worlds">${STAGES.map((s,i)=>{const st=worldStats(i);return `<div class="quest-progress-world"><b>${s.emoji} ${s.name}</b><span>🔤 ${st.letters}/${st.total}</span><span>🎮 ${st.wins}/7</span><span>📅 ${st.days}/2</span><button class="btn small outline" data-action="quest-open-world" data-stage="${i}">למשימות ←</button></div>`}).join('')}</div>
 <div class="quest-progress-backup"><h3>ההתקדמות שלך נשמרת בטלפון</h3><button class="btn outline" data-action="export-progress">📥 גיבוי לקובץ</button> <button class="btn outline" data-action="import-progress">📤 שחזור מגיבוי</button> <input id="progress-file" type="file" accept=".json,application/json" hidden><button class="btn ghost" data-action="reset-progress">🧹 איפוס כל הנתונים</button></div>`;
};

// Expose a read-only, small test API to verify milestones and balances.
window.ABCQuestAdventure={version:'7.5',worldStats,worldOpen,heroCheckpoint,skinRequirements,prestige:()=>({rank:GLORY.indexOf(currentGlory()),trophies:progress.stars,next:GLORY.find(g=>g.min>progress.stars)?.min??null}),
 fameThresholds:()=>GLORY.map(g=>g.min),
 economy:()=>({full:WIN_REWARD_TROPHIES,after:EXTRA_REWARD_TROPHIES,heroPrices:HERO_CREDIT_PRICES,heroGates:HERO_TROPHY_GATES,skinPrices:SKIN_CREDIT_PRICES}),
 state:()=>({page,world:gameWorldChoice,stars:progress.stars,credits:progress.credits,owned:[...progress.ownedHeroes],records:JSON.parse(JSON.stringify(progress.worldRecords))})};

function launchWorld(i){
 if(i<0||i>=STAGES.length)return;
 selectedStage=i;page='stage';mapPreview=i;render();
 if(!worldOpen(i))showToast(`🔒 כדי להיכנס ל${STAGES[i].name} מסיימים את המשימות בעולם הקודם.`);
}
function claimHero(id){
 if(!HEROES.some(h=>h.id===id))return;
 const i=worldByHero(id),slot=slotByHero(id),cp=heroCheckpoint(i,slot);
 if(!worldOpen(i)||!cp.ready){showToast('🔒 משלימים קודם את משימות הדמות בעולם הזה.');return;}
 if(progress.questClaimedHeroes[id]){showToast('✓ הפרס הזה כבר נפתח!');return;}
 const already=ownsHero(id),price=heroCreditPrice(id);
 if(!already&&progress.credits<price){showToast(`🪙 חסרים ${formatPrice(price-progress.credits)} קרדיטים לפתיחת הדמות`);return;}
 if(!already)progress.credits-=price;
 progress.questClaimedHeroes[id]=true;
 if(!already){progress.ownedHeroes.push(id);progress.ownedSkins[id]=[0];progress.equippedSkins[id]=0;}
 progress.questXP+=3;
 maybeAutoOpenWorldHero();
 save();
 render();
 makeJourneyReveal(id,already);
}
function makeJourneyReveal(id,wasAlready){
 document.querySelector('.abc-reveal-overlay')?.remove();
 const h=getHero(id),overlay=document.createElement('div');
 overlay.className='abc-reveal-overlay';
 overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');
 overlay.innerHTML=`<div class="abc-reveal-rays" aria-hidden="true"></div><div class="abc-reveal-box"><span class="abc-reveal-kicker">🌟 מסע האותיות 🌟</span>
 <h2>${wasAlready?'אתגר הדמות הושלם!':'דמות חדשה נפתחה!'}</h2><div class="abc-reveal-rarity">${STAGES[worldByHero(id)].emoji} פרס עולם ${worldByHero(id)+1}</div>
 <div class="abc-reveal-portrait">${artHtml(id,0,'quest-reveal-pic')}</div><h3>${h.name}</h3><p>${wasAlready?'הדמות נשמרה מהרכישות הקודמות שלך.':'הדמות נוספה לאוסף שלך!'} 🎉</p>
 <button class="abc-reveal-close">ממשיכים להרפתקה ←</button></div>
 ${Array.from({length:20},(_,i)=>`<i class="abc-confetti" style="--i:${i};--d:${(i%7)*.13}s"></i>`).join('')}`;
 document.body.appendChild(overlay);
 overlay.querySelector('.abc-reveal-close').addEventListener('click',()=>overlay.remove(),{once:true});
 overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.remove()});
 try{navigator.vibrate?.([40,35,85]);}catch(e){}
}

// Capturing handler prevents legacy open-stage/buy-hero paths from bypassing
// chapter quests, while leaving all original learning controls intact.
app.addEventListener('click',function(e){
 const el=e.target.closest('[data-action]');if(!el)return;
 const action=el.dataset.action;
 const custom=['quest-select-game-world','quest-open-world','quest-claim-hero','quest-open-hero','quest-practice-world','buy-hero','open-stage','start-lesson','stage-practice','jump-lesson','buy-skin'];
 if(!custom.includes(action))return;
 e.stopImmediatePropagation();e.preventDefault();
 if(action==='quest-select-game-world'){
  const world=el.dataset.world;
  if(world!=='all'&&!worldOpen(Number(world)))return showToast('🔒 העולם הזה עדיין נעול.');
  gameWorldChoice=world==='all'?'all':Number(world);render();return;
 }
 if(action==='quest-open-world'||action==='open-stage')return launchWorld(Number(el.dataset.stage));
 if(action==='quest-open-hero'){
  browsedHeroId=el.dataset.hero;page='heroes';render();return;
 }
 if(action==='quest-claim-hero'||action==='buy-hero')return claimHero(el.dataset.hero);
 if(action==='quest-practice-world'||action==='stage-practice'){
  const world=action==='stage-practice'?selectedStage:Number(el.dataset.stage);
  if(!worldOpen(world))return showToast('🔒 העולם נעול.');
  gameWorldChoice=world;page='games';render();return;
 }
 if(action==='start-lesson'){
  if(!worldOpen(selectedStage))return showToast('🔒 קודם מסיימים את העולם הקודם.');
  activeWord=0;lessonAt=stageLetters(selectedStage).findIndex(l=>!progress.learned[l.up]);
  if(lessonAt===-1)lessonAt=0;page='lesson';render();return;
 }
 if(action==='jump-lesson'){
  const l=locate(el.dataset.letter);
  if(!l||!worldOpen(l.stage))return showToast('🔒 האות הזו שייכת לעולם שעדיין נעול.');
  jumpToLesson(el.dataset.letter);return;
 }
 if(action==='buy-skin'){
  const req=skinRequirements(el.dataset.hero,Number(el.dataset.tier));
  if(!req.ready)return showToast('🔒 '+req.problems[0]);
  const tier=Number(el.dataset.tier),price=skinCreditPrice(el.dataset.hero,tier);
  if(progress.credits<price)return showToast(`🪙 חסרים ${formatPrice(price-progress.credits)} קרדיטים`);
  const original=window.ABCQuestJourneyOriginalBuySkin;
  const previous=SKIN_LEVELS[tier].price;
  SKIN_LEVELS[tier].price=price;
  try{original(el.dataset.hero,tier);}finally{SKIN_LEVELS[tier].price=previous;}
  return;
 }
},true);
window.ABCQuestJourneyOriginalBuySkin=buySkin;

// Some legacy functions navigate directly without passing through a click.
const baseJumpToLesson=jumpToLesson;
jumpToLesson=function(up){const l=locate(up);if(l&&!worldOpen(l.stage)){page='map';render();showToast('🔒 פותחים את העולם במפה.');return;}baseJumpToLesson(up)};

// Normalize restored backups, then re-run campaign state maintenance before render.
const previousRender=render;
render=function(){
 if(!progress.worldRecords||!progress.questClaimedHeroes)initQuest();
 maybeAutoOpenWorldHero();
 previousRender();
};
render();
})();
