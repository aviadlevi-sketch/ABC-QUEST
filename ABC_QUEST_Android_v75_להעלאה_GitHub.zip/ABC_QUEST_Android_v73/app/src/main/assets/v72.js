/* ABC QUEST 7.2 — learning/game fixes, credit idempotency, reward animations.
   Loaded after index.html's application code and the optional audio pack. */
(function () {
  'use strict';
  const DEBUG = !!window.ABC_QUEST_DEBUG;
  const trace = (...a) => { if (DEBUG) console.debug('[ABC QUEST 7.2]', ...a); };

  /* Progress is letter-based, not a sum of displayed scores. The old view placed
     "6 / 6" immediately beside "100%", which looked like "6100%" on Android RTL. */
  stagePercent = function (stage) {
    const letters = stageLetters(Number(stage));
    if (!letters.length) return 0;
    const learned = letters.filter(l => Boolean(progress.learned?.[l.up])).length;
    return Math.max(0, Math.min(100, Math.round(100 * learned / letters.length)));
  };
  overallPercent = function () {
    return Math.min(100, Math.max(0, Math.round(100 * learnedTotal() / 26)));
  };
  mapPage = function () {
    return `<div class="screen-back"><button class="btn ghost" data-action="navigate" data-page="home" aria-label="חזרה למסך הבית">→ 🏠 לבית</button></div>` +
      `<h1 class="screen-title">🗺️ מפת ההרפתקה</h1><div class="world-list">` +
      STAGES.map((s, i) => {
        const all = stageLetters(i), learned = all.filter(l => Boolean(progress.learned?.[l.up])).length;
        const pct = stagePercent(i);
        return `<article class="world-card" style="--shade:${s.shade}">` +
          `<div class="world-head"><div class="world-icon">${s.emoji}</div>` +
          `<div><span class="tag">עולם ${i+1} מתוך ${STAGES.length}</span><h3>${s.name}</h3></div></div>` +
          `<div class="letters" dir="ltr">${all.map(l => l.up).join(' · ')}</div>` +
          `<div class="progress-track" role="progressbar" aria-label="התקדמות ב${s.name}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}">` +
          `<div class="progress-fill" style="width:${pct}%"></div></div>` +
          `<div class="abc-world-progress"><span class="abc-count">🔤 נלמדו <b dir="ltr">${learned}/${all.length}</b> אותיות</span>` +
          `<span class="abc-percent">התקדמות: <b dir="ltr">${pct}%</b></span></div>` +
          `<button class="btn small" data-action="open-stage" data-stage="${i}">נכנסים ←</button></article>`;
      }).join('') + '</div>';
  };

  /* Award completion only once per letter, forever. Restore a claimed ledger
     from legacy progress to avoid re-awarding letters learned before upgrading. */
  function migrateClaimedLetters() {
    const ledger = progress.claimedLetterRewards && typeof progress.claimedLetterRewards === 'object'
      ? progress.claimedLetterRewards : {};
    for (const letter of LETTERS) {
      if (progress.learned?.[letter.up]) ledger[letter.up] = true;
    }
    progress.claimedLetterRewards = ledger;
    save();
  }
  migrateClaimedLetters();
  markLearned = function (up) {
    const letter = locate(String(up || '').toUpperCase());
    if (!letter) return;
    const key = letter.up;
    if (progress.claimedLetterRewards[key] || progress.learned[key]) {
      if (!progress.claimedLetterRewards[key]) progress.claimedLetterRewards[key] = true;
      if (!progress.learned[key]) progress.learned[key] = Date.now();
      save();
      trace('already rewarded:', key);
      return;
    }
    progress.learned[key] = Date.now();
    progress.claimedLetterRewards[key] = true;
    progress.stars = Math.max(0, Number(progress.stars) || 0) + 15;
    progress.credits = Math.max(0, Number(progress.credits) || 0) + 10;
    save();
    trace('first-time letter reward:', key);
  };

  /* Speak the *whole* sequence. Do not read it as a single string: on Android,
     voice fallback uses only the first letter. Use a separate clip per letter,
     giving each clip its own ended event. Human MP3s override embedded names. */
  let readingRun = 0;
  let readingClip = null;
  let readingPause = null;
  const originalStopAudio = stopAudio;
  function cancelReadingSequence() {
    ++readingRun;
    if (readingClip) {
      readingClip.onended = null; readingClip.onerror = null;
      try { readingClip.pause(); readingClip.currentTime = 0; } catch (_) {}
      readingClip = null;
    }
    if (readingPause) { clearTimeout(readingPause); readingPause = null; }
  }
  stopAudio = function () {
    cancelReadingSequence();
    originalStopAudio();
  };
  listenReadSequence = function () {
    if (!game || page !== 'game' || game.question?.type !== 'read') return;
    const letters = [...(game.question.sequence || [])];
    if (!letters.length) return;
    if (!soundOn) { showToast('🔇 הפעילו קול כדי לשמוע את הדוגמה'); return; }
    stopAudio();
    const run = ++readingRun;
    let index = 0;
    function nextClip() {
      if (run !== readingRun || index >= letters.length) { readingClip = null; return; }
      const letter = String(letters[index++]).toUpperCase();
      const src = window.ABC_QUEST_AUDIO?.names?.[letter] || AUDIO?.[letter]?.name;
      if (!src) { readingPause = setTimeout(nextClip, 180); return; }
      let advanced = false;
      const advance = () => {
        if (advanced || run !== readingRun) return;
        advanced = true;
        readingClip = null;
        readingPause = setTimeout(nextClip, 170);
      };
      try {
        const player = new Audio(src);
        readingClip = player;
        player.volume = 1;
        player.onended = advance;
        player.onerror = advance;
        const p = player.play();
        if (p && typeof p.catch === 'function') p.catch(advance);
      } catch (e) { advance(); }
    }
    trace('playing full reading sequence:', letters.join(' '));
    nextClip();
  };

  /* Reward reveal — original art; different animation for heroes and skins. */
  function makeReveal(kind, id, tier) {
    const h = getHero(id);
    if (!h) return;
    document.querySelector('.abc-reveal-overlay')?.remove();
    const skin = Number(tier) || 0;
    const title = kind === 'hero' ? 'דמות חדשה נפתחה!' : 'סקין חדש נפתח!';
    const name = kind === 'hero' ? h.name : (HERO_SKIN_NAMES?.[id]?.[skin] || h.name);
    const rarity = kind === 'hero' ? 'גיבור חדש!' : ['מקורי','נדיר','אפי','אגדי'][skin] || 'נדיר';
    const overlay = document.createElement('div');
    overlay.className = 'abc-reveal-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', title);
    const imgUrl = skinImage(id, skin);
    overlay.innerHTML = `<div class="abc-reveal-rays" aria-hidden="true"></div>` +
      `<div class="abc-reveal-box"><div class="abc-reveal-kicker">✨ ABC QUEST ✨</div>` +
      `<h2>${title}</h2><div class="abc-reveal-rarity">🏆 ${rarity}</div>` +
      `<div class="abc-reveal-portrait"><img src="${imgUrl}" alt="${name}"></div>` +
      `<h3>${name}</h3><p>איזה יופי! הפרס שלך 🎉</p>` +
      `<button type="button" class="abc-reveal-close">ממשיכים להרפתקה ←</button></div>` +
      Array.from({length:20},(_,i)=>`<i class="abc-confetti" style="--i:${i};--d:${(i%7)*.14}s"></i>`).join('');
    document.body.appendChild(overlay);
    const dismiss = () => { overlay.remove(); };
    overlay.querySelector('.abc-reveal-close').addEventListener('click', dismiss, {once:true});
    overlay.addEventListener('click', e=>{ if (e.target===overlay) dismiss(); });
    overlay.querySelector('.abc-reveal-close').focus({preventScroll:true});
    try { if (navigator.vibrate) navigator.vibrate([60,40,90]); } catch (_) {}
  }
  const originalBuyHero = buyHero;
  buyHero = function (id) {
    const wasOwned = ownsHero(id);
    originalBuyHero(id);
    if (!wasOwned && ownsHero(id)) makeReveal('hero', id, 0);
  };
  const originalBuySkin = buySkin;
  buySkin = function (id, tier) {
    const wasOwned = ownsSkin(id, Number(tier));
    originalBuySkin(id, tier);
    if (!wasOwned && ownsSkin(id, Number(tier))) makeReveal('skin', id, Number(tier));
  };

  /* Compact portrait layout for 360×640 and small Android displays.
     Use CSS first. Zoom only if height still exceeds the usable space, keeping
     a fallback scrollable region for enlarged system text and accessibility. */
  let queuedFit = 0;
  function fitLearningPage() {
    const main = document.querySelector('.main');
    if (!main) return;
    const dialog = document.querySelector('.modal-backdrop .modal');
    if(dialog) {
      dialog.style.zoom = '1';
      const natural = dialog.getBoundingClientRect().height;
      const available = window.innerHeight - 18;
      if(natural > available) dialog.style.zoom = Math.max(.78, available / natural).toFixed(3);
    }
    const target = page === 'lesson' ? main.querySelector('.lesson-card') :
      page === 'game' ? main.querySelector('.game-card') : null;
    main.classList.toggle('abc-compact-page', Boolean(target));
    if (!target) return;
    target.style.zoom = '1';
    const nav = document.querySelector('.mobile-nav');
    const navTop = nav && getComputedStyle(nav).display !== 'none' ? nav.getBoundingClientRect().top : innerHeight;
    const top = target.getBoundingClientRect().top;
    const available = Math.max(0, navTop - top - 12);
    const natural = target.getBoundingClientRect().height;
    // Keep controls legible. On the tiniest devices a small amount of scroll
    // is safer than unreadable 20px tap targets.
    const factor = natural>available && available>0 ? Math.max(.78, Math.min(1, available/natural)) : 1;
    target.style.zoom = factor.toFixed(3);
    trace('fit', page, {available, natural, factor});
  }
  const previousRender = render;
  render = function () {
    const oldPage = document.querySelector('.main')?.dataset.abcScreen;
    previousRender();
    const main = document.querySelector('.main');
    document.body.classList.toggle('abc-modal-compact', !!document.querySelector('.modal-backdrop .modal'));
    if(main) {
      main.dataset.abcScreen = page;
      if (oldPage !== page) main.scrollTop = 0;
    }
    cancelAnimationFrame(queuedFit);
    queuedFit = requestAnimationFrame(fitLearningPage);
  };
  window.addEventListener('resize', () => requestAnimationFrame(fitLearningPage));
  fitLearningPage();

  window.ABCQuestV72 = {
    version:'7.2',
    getStagePercent: (index)=>stagePercent(index),
    currentProgress: ()=>({stars:progress.stars,credits:progress.credits,claimed:{...progress.claimedLetterRewards}}),
    testReading: sequence=>{game={question:{type:'read',sequence}};page='game';listenReadSequence();}
  };
})();
