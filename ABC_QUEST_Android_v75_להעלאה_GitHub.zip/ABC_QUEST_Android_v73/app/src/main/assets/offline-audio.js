/* Optional licensed female-voice recordings stored inside the APK. */
(function(){
const manifest=window.ABC_QUEST_AUDIO||{names:{},phonemes:{},words:{}};
let clip=null;
function playClip(src,fallback){
 if(!src||!soundOn){fallback();return;}
 try{
  if(clip){clip.pause();clip=null;}
  stopAudio();
  clip=new Audio(src);clip.preload='auto';
  const p=clip.play();if(p&&p.catch)p.catch(()=>fallback());
  clip.addEventListener('error',fallback,{once:true});
 }catch(e){fallback();}
}
const oldPlay=playAudio;
playAudio=function(letter,kind){
 const key=String(letter||'').toUpperCase();
 const src=(kind==='name'?manifest.names?.[key]:kind==='sound'?manifest.phonemes?.[key]:'');
 return playClip(src,()=>oldPlay(letter,kind));
};
const oldVocab=playVocabulary;
playVocabulary=function(letter,index){
 const word=WORD_BANK?.[letter]?.[index]?.word||'';
 const slug=word.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
 return playClip(manifest.words?.[slug],()=>oldVocab(letter,index));
};
})();
