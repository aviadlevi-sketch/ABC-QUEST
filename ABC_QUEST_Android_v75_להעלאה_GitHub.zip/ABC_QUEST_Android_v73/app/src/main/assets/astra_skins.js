window.ABC_QUEST_ASTRA_SKINS=["images/astra/0.jpg","images/astra/1.jpg","images/astra/2.jpg","images/astra/3.jpg"];
