package com.abcquest.kids;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.CookieManager;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Locale;

/** Offline WebView shell. Only the bundled local game is loaded.
 *  The optional voice exercise starts Android's own recognition activity,
 *  without taking microphone permissions or storing recordings.
 */
public class MainActivity extends Activity {
    private static final int SPEECH_REQ = 404;
    private WebView webView;

    public final class AndroidBridge {
        @JavascriptInterface
        public void startSpeechRecognition() {
            runOnUiThread(() -> {
                Intent speech = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag());
                speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,
                                Locale.US.toLanguageTag());
                speech.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4);
                speech.putExtra(RecognizerIntent.EXTRA_PROMPT,
                                "Say the English letter names");
                try {
                    startActivityForResult(speech, SPEECH_REQ);
                } catch (ActivityNotFoundException e) {
                    notifySpeech("");
                } catch (SecurityException e) {
                    notifySpeech("");
                }
            });
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(20,48,144));
        getWindow().setNavigationBarColor(Color.rgb(11,24,84));
        webView = new WebView(this);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(Color.rgb(11,24,84));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setTextZoom(100);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep child users inside the local application.
                return !"file".equals(request.getUrl().getScheme());
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void notifySpeech(String transcript) {
        if (webView == null) return;
        final String js = "window.abcNativeSpeechResult(" + JSONObject.quote(transcript) + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != SPEECH_REQ) return;
        String transcript = "";
        if (resultCode == RESULT_OK && data != null) {
            ArrayList<String> texts = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (texts != null && !texts.isEmpty()) transcript = texts.get(0);
        }
        notifySpeech(transcript);
    }

    @Override
    @Deprecated
    public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript(
            "typeof window.abcAndroidBack==='function' ? window.abcAndroidBack() : false",
            handled -> {
                if (!"true".equals(handled)) {
                    new AlertDialog.Builder(this)
                        .setTitle("לצאת מהמשחק?")
                        .setPositiveButton("יציאה", (dialog, which) -> finish())
                        .setNegativeButton("להמשיך לשחק", null)
                        .show();
                }
            });
    }

    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }
    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
